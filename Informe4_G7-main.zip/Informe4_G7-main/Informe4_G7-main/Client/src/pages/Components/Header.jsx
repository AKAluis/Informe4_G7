import React from "react";
import "../../App.css";

function Header() {
  return <div></div>;
}

export default Header;
