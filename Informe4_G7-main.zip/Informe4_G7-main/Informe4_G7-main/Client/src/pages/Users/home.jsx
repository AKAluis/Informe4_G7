import React from 'react'

function home() {
  return (
    <div>
      <h1>HOLA</h1>
    </div>
  )
}

export default home
